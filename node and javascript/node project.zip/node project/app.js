var express = require('express');
var bodyParser = require('body-parser');
var app=express();

var path= require("path");
var publicPath=path.resolve(__dirname,"public");
app.use(express.static(publicPath));
var handlebars = require('express-handlebars').create({defaultLayout:'main'});

app.use(bodyParser.urlencoded({ extended: false }));

app.engine('handlebars', handlebars.engine);
app.set('view engine', 'handlebars');

var session= require('express-session');

var sessionOptions = {
	secret: 'secret cookie thang',
	resave: true,
	saveUninitialized: true
};
app.use(session(sessionOptions));

app.get('/', function(req,res){
	var content=req.headers;
	res.render('index');
});
var birds=[
{num:3, nam:"Bald Eagle"},
{num:7, nam:"Yellow Billed Duck"},
{num:4, nam:"Great Cormorant"}
];

var set=0;
// birds getter
app.get('/birds', function(req,res){
	var filtered;
	if(!req.session.set){
		filtered=0;
	}
	else{
		filtered=req.session.set;
	}
	//console.log(filtered);
	var ans=birds.filter(function(bird){
		return bird.num>=filtered;
	})
		res.render('birds',{'birds':ans});
	

	
});
//middleware stuff
app.use(function(req, res, next) {
	console.log(req.method, req.path);
	next();
});

//birds post
app.post('/birds', function(req, res) {
	//console.log(req.body);
	var check=true;
	birds.forEach(function(elem){
		//console.log(req.body.nam);
		if(elem.nam===req.body.nam){
			elem.num=elem.num+1;
			check=false;
		
		}
	});
	if(check){
		var obj={num:1, nam:req.body.nam};
		birds.push(obj);
	}
	

	
	res.redirect(302,'/birds');
});
//settings get
app.get('/settings',function(req,res){
	res.render('settings');
});
//settings post
app.post('/settings', function(req,res){
	req.session.set=req.body.setting;
	//console.log(req.body.setting);
	res.redirect(302,'/settings');
});

app.listen(3000);
console.log("Started server on port 3000");
 var r=require('request');
 r('http://foureyes.github.io/csci-ua.0480-fall2014-002/homework/02/2014-06-15-heat-spurs.json', function (error, answer, data) {
  if (!error && answer.statusCode == 200) {
    printit(data);
  }
});


r('http://foureyes.github.io/csci-ua.0480-fall2014-002/homework/02/2014-04-09-thunder-clippers.json', function (error, answer, data) {
  if (!error && answer.statusCode == 200) {
    printit(data);
  }
});
var printit=function(data){
 var parsed = JSON.parse(data);

 
//t1 name
 var t1name=parsed[0].team;
 var t1 = parsed.filter(function(arg){
 		return arg.team== t1name;
 });
//console.log(t1);

//use filter to get sanantonio
//t2 name
var t2 = parsed.filter(function(arg){
 		return arg.team!=t1name;
 });
var t2name=t2[0].team;
//console.log(t2name);

var finalScore= function(sm){
	var result=0;
	sm.forEach(function(args){
		var threesMad = args.threesMade *3;
		var freeThrowsMade= args.freeThrowsMade;
		var twos= (args.fieldGoalsMade)-(args.threesMade);
		var twosMade= (twos)*2;
		result= (threesMad+freeThrowsMade+twosMade)+result;
		
		return result;
	});
	return result;

};


var rebounds= function(sm){
	var total=0;
	sm.forEach(function(args){
		var offensiveRebound= args.offensiveRebounds;
		var defensiveRebound= args.defensiveRebounds;
		total=total+offensiveRebound+defensiveRebound;
		return total;
	});
	return total;
};

var threepercent= function(sm){
	var player;
	var best=0;
	sm.forEach(function(args){
		var threesMad = args.threesMade *3;
		var freeThrowsMade= args.freeThrowsMade;
		var twos= (args.fieldGoalsMade)-(args.threesMade);
		var twosMade= (twos)*2;
		var scored= (threesMad+freeThrowsMade+twosMade);
		if(scored>=10){
			var percent=(threesMad/scored)*100;
			if(percent>best){
				best=percent;
				player=args.name;
			}
		}
		return player;

	});
	return player;
};


var nonguard=function(sm){
	var player;
	var stat=0;
	var arr=[];
	sm.forEach(function(args){
		var position=args.position;
		if(position!="G"){
			var assist= args.assists;
			if (assist>stat) {
				stat=assist;
				player=args.name;
				arr[0]=player;
				arr[1]=stat;
			}
		}
		

	});
	return arr;
};


var turnover= function(sm){
	
	 var names=sm.map(function(args){
		var assist= args.assists;
		var turn=args.turnovers;
		if(turn>assist){
			return args.name;
			
		}

	});
	return names;
};
var main= function(sm,t1,t2,name1,name2){
	console.log("Final Score: "+name1+" "+finalScore(t1)+",  "+name2+" "+finalScore(t2));
    console.log("=========");

    console.log("*Player with highest percentage of points from three pointers: "+threepercent(sm));
    //for rebounds
    var reb1= rebounds(t1);
    var reb2= rebounds(t2);
    if(reb1>reb2){
    	console.log("*Team with most rebounds: "+name1+" with "+reb1);
    }
    else if(reb2>reb1){
    	console.log("*Team with most rebounds: "+name2+" with "+reb2);
    }
    //console.log(rebounds(miami));
    var nong=nonguard(sm);
    console.log("*Non guard player with most assists: "+nong[0]+" with "+ nong[1]);
    console.log("*Players with more turnovers than assists:");
    var turns=turnover(sm);
    for(var i=0;i<turns.length;i++){
    	if(turns[i]!= undefined){
    		console.log(" "+turns[i]);
    	}
    }
    console.log("   ");

};
main(parsed,t1,t2,t1name,t2name);
};

